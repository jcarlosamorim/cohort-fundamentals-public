#!/usr/bin/env node

const { spawnSync } = require('child_process');
const path = require('path');

const BASE_SCRIPT = path.resolve(
  __dirname,
  '..',
  '..',
  'squad-creator',
  'scripts',
  'generate-squad-greeting.js',
);

const base = require(BASE_SCRIPT);

if (require.main === module) {
  const result = spawnSync(process.execPath, [BASE_SCRIPT, ...process.argv.slice(2)], {
    stdio: 'inherit',
  });

  if (result.error) {
    console.error('Error:', result.error.message);
    process.exit(1);
  }

  process.exit(result.status ?? 0);
}

module.exports = base;
