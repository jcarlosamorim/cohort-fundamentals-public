# Workflow: Full Genius Pipeline

**Workflow ID:** full-genius-pipeline
**Version:** 1.0
**Purpose:** Pipeline completo: assessment → análise multi-framework → recomendação → blueprint
**Orchestrator:** @zona-genialidade-chief
**Direction:** Unidirecional (NUNCA volta)
**Target:** Alunos do Cohort Fundamentals (30 min assessment → entrega completa)

---

## Overview

```
PHASE 1              PHASE 2                    PHASE 3              PHASE 4
ASSESSMENT     →     ANALYSIS (Tiers)     →     MATCHING       →    BLUEPRINT
                                                                        |
43 perguntas        Tier 0: Hendricks          Scoring 4 layers      10 seções
5 seções            Tier 1: 4 agents (||)      Top 3 squads         documento final
                    Tier 2: 2 agents (||)      Dream Squad          próximos passos
```

---

## Phases

### Phase 1: ASSESSMENT
**Agent:** @zona-genialidade-chief
**Mode:** Interactive (elicit: true)
**Duration:** ~30 min
**Task:** `tasks/run-assessment.md`

```yaml
steps:
  - id: "1.1"
    action: "Intake — 3 perguntas de contexto"
    questions:
      - "Qual sua situação profissional atual?"
      - "Por que entrou no cohort?"
      - "Qual sua maior dor agora?"

  - id: "1.2"
    action: "Assessment — 43 perguntas em 5 seções"
    sections:
      - name: "Contexto Pessoal"
        questions: 8
        feeds: ["all frameworks"]
      - name: "Atividades & Energia"
        questions: 12
        feeds: ["hendricks", "sullivan", "kolbe"]
      - name: "Talentos & Padrões"
        questions: 10
        feeds: ["clifton", "hogshead"]
      - name: "Estilo de Negócios"
        questions: 8
        feeds: ["hamilton", "hormozi"]
      - name: "Visão & Ambição"
        questions: 5
        feeds: ["sullivan", "hormozi"]

  - id: "1.3"
    action: "Salvar assessment-result.yaml"
    output: "data/assessments/{user_slug}-assessment.yaml"
```

**Gate QG-002:** >= 40/43 perguntas respondidas, todas seções preenchidas → Avança
**Veto:** < 35 perguntas → Assessment incompleto, não calcular

---

### Phase 2: MULTI-FRAMEWORK ANALYSIS
**Agents:** 7 especialistas em 3 tiers
**Mode:** Autonomous
**Duration:** 15-30 min
**Task:** `tasks/analyze-genius-profile.md`

```yaml
tiers:
  tier_0_foundation:
    description: "Ancora toda a análise"
    execution: "Sequencial — DEVE completar antes de Tier 1"
    agents:
      - id: "@gay-hendricks"
        framework: "Zone of Genius Model"
        output: "zona_atual + zona_ideal + upper_limit_problem"
        confidence_min: 0.6

  tier_1_profiling:
    description: "4 análises paralelas"
    execution: "PARALELO — todas rodam simultaneamente"
    depends_on: [tier_0]
    agents:
      - id: "@don-clifton"
        framework: "CliftonStrengths"
        output: "top_5_strengths + domínio_dominante"
      - id: "@dan-sullivan"
        framework: "Unique Ability"
        output: "unique_ability + mapa_4_zonas"
      - id: "@roger-hamilton"
        framework: "Wealth Dynamics"
        output: "wealth_profile + wealth_spectrum_level"
      - id: "@alex-hormozi"
        framework: "Value Equation"
        output: "grand_slam_offer + monetization_path"

  tier_2_refinement:
    description: "Refinamento pós-profiling"
    execution: "PARALELO — rodam simultaneamente"
    depends_on: [tier_1]
    agents:
      - id: "@kathy-kolbe"
        framework: "Kolbe A Index"
        output: "action_modes + modo_dominante"
      - id: "@sally-hogshead"
        framework: "Fascination Advantage"
        output: "arquetipo + positioning"

  synthesis:
    agent: "@zona-genialidade-chief"
    depends_on: [tier_2]
    action: "Sintetizar 7 análises"
    output:
      convergencias: "3+ frameworks alinham (FORTE)"
      insights_unicos: "Apenas 1 framework viu (VALIOSO)"
      contradicoes: "Frameworks discordam (INVESTIGAR)"
    save: "data/{user_slug}/genius-profile.yaml"
```

**Gate QG-003:** 7 análises completas + >= 3 convergências + confiança média >= 0.7 → Avança
**Veto:** < 5 análises completas → Reprocessar tiers faltantes

---

### Phase 3: SQUAD MATCHING
**Agent:** @zona-genialidade-chief
**Mode:** Autonomous
**Duration:** 5-15 min
**Task:** `tasks/recommend-squad.md`

```yaml
steps:
  - id: "3.1"
    action: "Scoring matrix — 4 layers ponderadas"
    layers:
      - name: "Hamilton Profile"
        weight: 0.40
        source: "@roger-hamilton output"
      - name: "Kolbe Action Modes"
        weight: 0.30
        source: "@kathy-kolbe output"
      - name: "Clifton Strengths"
        weight: 0.20
        source: "@don-clifton output"
      - name: "Context Bonus"
        weight: 0.10
        source: "assessment contexto"

  - id: "3.2"
    action: "Ranquear squads disponíveis"
    pool: "Todos os squads do ecossistema"

  - id: "3.3"
    action: "Gerar Top 3 + Dream Squad"
    output:
      top_3:
        - "rank, squad_name, score, scoring_breakdown, racional"
      dream_squad:
        - "Squad personalizado projetado para o perfil"

  - id: "3.4"
    action: "Salvar squad-recommendation.yaml"
    save: "data/{user_slug}/squad-recommendation.yaml"
```

**Gate:** Top 3 com score >= 60 + racional documentado → Avança
**Veto:** Nenhum squad com score >= 40 → Revisar assessment

---

### Phase 4: BLUEPRINT GENERATION
**Agent:** @zona-genialidade-chief
**Mode:** Autonomous
**Duration:** 10-20 min
**Task:** `tasks/generate-blueprint.md`

```yaml
steps:
  - id: "4.1"
    action: "Gerar Blueprint com 10 seções"
    sections:
      1: "30-Second Profile (resumo executivo)"
      2: "Zone Diagnostics (Hendricks — zona atual vs ideal)"
      3: "Talent Map (Clifton — top 5 forças)"
      4: "Unique Ability (Sullivan — habilidade única)"
      5: "Wealth Profile (Hamilton — perfil de riqueza)"
      6: "Squad Recommendation (Top 3 + Dream Squad)"
      7: "Monetization Plan (Hormozi — como monetizar)"
      8: "Execution Style (Kolbe — como age)"
      9: "Positioning (Hogshead — como fascina)"
      10: "Next Steps (Checklist acionável)"

  - id: "4.2"
    action: "Verificar coerência entre seções"
    checks:
      - "Seção 7 (monetização) alinha com seção 5 (wealth profile)?"
      - "Seção 8 (execução) alinha com seção 4 (unique ability)?"
      - "Seção 6 (squad) alinha com seção 3 (talentos)?"
    veto_if: "Contradição não resolvida entre seções"

  - id: "4.3"
    action: "Salvar genius-zone-blueprint.md"
    save: "data/{user_slug}/genius-zone-blueprint.md"
```

**Gate QG-004:** 10/10 seções preenchidas + zero contradições + next steps acionáveis → ENTREGA
**Veto:** Seção faltando ou contradição grave → Loop interno de correção

---

## Wave Map (Paralelização)

```
SEQUENCIAL:
  Phase 1 (Assessment) → Phase 2 → Phase 3 → Phase 4

DENTRO DA PHASE 2:
  Tier 0 (sequencial) → Tier 1 (4 agents PARALELO) → Tier 2 (2 agents PARALELO) → Synthesis
```

---

## Guardrails

1. **Idempotency:** Mesmo assessment → mesmas análises (determinístico por framework)
2. **Audit trail:** Cada agent loga confiança + fontes usadas do assessment
3. **Manual escape:** User pode pular assessment e fornecer dados direto
4. **Retry logic:** Agent com confiança < 0.5 → re-analisar com dados adicionais
5. **Data isolation:** Cada user tem diretório próprio em data/{user_slug}/
