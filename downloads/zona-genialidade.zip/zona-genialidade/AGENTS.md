# AGENTS.md: Runbook Operacional do Squad Zona de Genialidade

> **LEIA ESTE ARQUIVO ANTES DE QUALQUER COISA.**
> Se você é um agente (Claude Code, Codex, Hermes ou qualquer LLM) e alguém acabou de
> instalar este squad ou pediu para "rodar a zona de genialidade", este arquivo é a sua
> única instrução de boot. Ele diz quem começa, o que fazer em cada etapa, o que salvar
> onde e o que nunca fazer. Os outros arquivos são profundidade, este é a ordem.

**Versão:** 1.0.0
**Última revisão:** 2026-07-24
**Escopo:** atendimento de um cliente (ou aluno) de ponta a ponta, do primeiro "oi" até o Blueprint entregue.

---

## 1. A resposta de 10 segundos

**O primeiro agente é sempre o `zona-genialidade-chief`.** Nenhum outro.

```
/ZonaGenialidade:tasks:start
```

Os 7 especialistas (Hendricks, Clifton, Sullivan, Hamilton, Hormozi, Kolbe, Hogshead)
**não são porta de entrada**. Eles são chamados pelo Chief na Etapa 2, depois que os dados
já existem. Chamar `gay-hendricks` direto no começo é o erro número 1 deste squad: ele vai
tentar classificar uma pessoa sobre a qual não há um único dado coletado, e vai alucinar
um perfil.

Regra: **sem assessment não existe análise. Sem análise não existe Blueprint.**

---

## 2. Fonte da verdade (qual arquivo manda)

| Pergunta | Arquivo que responde |
|---|---|
| Qual a ordem das etapas? | **este AGENTS.md** |
| Quais perguntas fazer ao cliente? | `tasks/run-assessment.md` (cânone executável) |
| Como o Chief fala e se comporta? | `agents/zona-genialidade-chief.md` |
| Como cada framework analisa? | `agents/{nome-do-mind}.md` |
| Como pontuar o squad ideal? | `tasks/recommend-squad.md` |
| Qual o formato do entregável? | `tasks/generate-blueprint.md` |
| Visão geral em 1 tela | `workflows/full-genius-pipeline.md` |

**Conflito conhecido:** `agents/zona-genialidade-chief.md` descreve um questionário de 45
perguntas em 7 blocos. `tasks/run-assessment.md` descreve 43 perguntas em 5 seções.
**Vale o run-assessment.** O bloco do Chief é material de design, não roteiro de execução.
Se você seguir o Chief, os campos que a Etapa 2 espera não vão existir com os nomes certos.

---

## 3. As 5 etapas

### Etapa 0. Intake e consentimento (2 min, humano presente)

**Executa:** `zona-genialidade-chief`

Faça exatamente 3 perguntas antes de abrir o questionário:

1. Qual é a sua situação profissional hoje? (empregado, freelancer, empreendedor, em transição)
2. O que te trouxe até aqui?
3. Se você pudesse resolver UMA coisa na sua vida profissional agora, o que seria?

Depois confirme: "Você tem 30 minutos ininterruptos agora?"

**Gate QG-001 (bloqueia):** as 3 respostas existem e a pessoa confirmou os 30 minutos.
Se ela não tem o tempo, **pare aqui**. Assessment picado em pedaços gera perfil inconsistente,
porque as respostas de energia mudam com o humor do dia.

**Pergunte também:** "já fez DISC, MBTI, CliftonStrengths ou Kolbe oficial?" Se sim, guarde
como âncora de calibração. Não pule perguntas por causa disso: na Etapa 2, quando a estimativa
do squad divergir do resultado formal, **o formal vence**.

---

### Etapa 1. Assessment (30 min, humano presente)

**Executa:** `zona-genialidade-chief`
**Roteiro:** `tasks/run-assessment.md`

43 perguntas em 5 seções, via `AskUserQuestion`, uma seção por vez:

| Seção | Tempo | Perguntas | Alimenta |
|---|---|---|---|
| 1. Contexto Pessoal | 5 min | 8 | todos |
| 2. Atividades e Energia | 8 min | 12 | Hendricks, Sullivan, Kolbe |
| 3. Talentos e Padrões | 7 min | 10 | Clifton, Hogshead |
| 4. Estilo de Negócios | 5 min | 8 | Hamilton, Hormozi |
| 5. Visão e Ambição | 5 min | 5 | Sullivan, Hormozi |

Entre seções, dê progresso visual (20%, 40%, 60%, 80%, 100%) e um comentário curto. O cliente
está entregando medo e desejo, não preenchendo formulário. Tom de mentor, nunca de clínica.

**Gate QG-002 (bloqueia):**
- 40 ou mais das 43 respondidas
- as 5 perguntas abertas com resposta substantiva (mais de 20 caracteres)
- nenhuma seção com mais de 50% em branco

**Veto:** abaixo de 35 respostas, **não avance**. Volte e preencha as lacunas.

**Salva em:** `data/assessments/{slug}-assessment.yaml`

---

### Etapa 2. Análise multi-framework (15 a 30 min, autônomo)

**Executa:** os 7 especialistas, orquestrados pelo Chief
**Roteiro:** `tasks/analyze-genius-profile.md`

Ordem obrigatória. Ela não é estética, é dependência de dados:

```
Tier 0   gay-hendricks          sozinho, primeiro, sempre
             ↓  (zona atual ancora a leitura de todos os outros)
Tier 1   don-clifton  ·  dan-sullivan  ·  roger-hamilton  ·  alex-hormozi     (paralelo)
             ↓  (perfil de riqueza calibra Kolbe; forças calibram Hogshead)
Tier 2   kathy-kolbe  ·  sally-hogshead                                        (paralelo)
             ↓
Síntese  zona-genialidade-chief
```

Na síntese, produza três listas separadas e **não misture**:
- **Convergências:** onde 3 ou mais frameworks apontam o mesmo. É o sinal forte.
- **Insights únicos:** onde só 1 framework viu algo. Costuma ser o mais valioso.
- **Contradições:** onde os frameworks brigam. **Documente, não esconda e não force acordo.**
  Contradição quase sempre é a pessoa real aparecendo (ex: talento criativo com instinto
  conservador na execução). Vire nuance no Blueprint, não erro a corrigir.

**Gate QG-003 (bloqueia):** 7 análises completas, confiança média >= 0.7, 3 ou mais convergências.
**Veto:** menos de 5 análises completas, reprocesse os tiers que faltam antes de seguir.

**Salva em:** `data/{slug}/genius-profile.yaml`

---

### Etapa 3. Matching de squad (5 a 15 min, autônomo)

**Executa:** `zona-genialidade-chief`
**Roteiro:** `tasks/recommend-squad.md`

Score composto, pesos fixos:

| Camada | Peso | Origem |
|---|---|---|
| Perfil Hamilton | 40% | `roger-hamilton` |
| Action Modes Kolbe | 30% | `kathy-kolbe` |
| Domínio Clifton | 20% | `don-clifton` |
| Bônus de contexto | 10% | assessment |

Entrega Top 3 com racional específico (nunca genérico) mais um Dream Squad projetado sob medida.

**Gate:** Top 3 com score >= 60 e racional escrito.
**Se nenhum squad passar de 40:** não empurre um match ruim. Promova o Dream Squad a
recomendação principal e diga com todas as letras que o ecossistema atual não tem a peça certa.

**Salva em:** `data/{slug}/squad-recommendation.yaml`

---

### Etapa 4. Blueprint e entrega (10 a 20 min, autônomo)

**Executa:** `zona-genialidade-chief`
**Roteiro:** `tasks/generate-blueprint.md`

10 seções: perfil em 30 segundos, zona (Hendricks), talentos (Clifton), habilidade única
(Sullivan), riqueza (Hamilton), squad recomendado, monetização (Hormozi), execução (Kolbe),
posicionamento (Hogshead), próximos passos.

**Gate QG-004 (bloqueia):**
- 10 de 10 seções com dados reais da pessoa, zero placeholder
- coerência cruzada: monetização bate com perfil de riqueza, execução bate com habilidade única,
  squad bate com talentos
- plano 30-60-90 com ações datadas
- pelo menos uma ação que começa **hoje**

**Salva em:** `data/{slug}/genius-zone-blueprint.md`

Na entrega, mostre o resumo executivo primeiro (zona, perfil, top 3 talentos, habilidade única,
arquétipo, estilo de ação, top 3 squads, próximo passo de hoje) e só depois ofereça o documento
completo. Ninguém lê 10 seções de cara.

---

## 4. Regras invioláveis

1. **Nunca pule o assessment.** Sem dados brutos, os 7 agentes inventam. É o único jeito
   de este squad produzir lixo confiante.
2. **Nunca chame um especialista como porta de entrada.** Sempre o Chief primeiro.
3. **Nunca entregue Blueprint com menos de 5 análises.** Marque confiança baixa e diga qual
   framework ficou indicativo.
4. **Nunca force convergência.** Contradição documentada vale mais que síntese limpa e falsa.
5. **Nunca use jargão sem traduzir.** "Quick Start alto" vira "você é rápido pra começar e
   detesta plano longo". O cliente não conhece Kolbe.
6. **Nunca prometa absoluto.** "Seu perfil tende a" e não "você definitivamente é".
7. **Nunca entregue autoconhecimento sem plano de cobrança.** O produto final é receita, não
   relatório bonito. Insight sem próximo passo é hobby.
8. **Nunca estoure os 30 minutos** da parte em que o cliente está presente.

---

## 5. Atendimento a cliente pagante (diferenças do aluno de cohort)

O squad nasceu para alunos do Cohort Fundamentals. Rodando com cliente externo, ajuste:

- **Slug:** use kebab-case do nome completo, `data/maria-santos/`. Um diretório por pessoa,
  sempre. Nunca misture clientes no mesmo diretório.
- **Etapa 3:** o cliente externo geralmente não vai "criar um squad no ecossistema". Traduza a
  recomendação para o vocabulário dele: modelo de negócio, papel que ele ocupa, quem ele precisa
  contratar primeiro. O algoritmo é o mesmo, a embalagem muda.
- **Confidencialidade:** o assessment coleta medo de sabotagem, crença sobre merecimento e meta
  de faturamento. Isso não sai do diretório da pessoa, não vira exemplo em aula e não entra em
  post sem autorização escrita.
- **Entregável:** para cliente pagante, gere também a versão HTML do Blueprint. Markdown cru
  não parece entrega de consultoria paga.

---

## 6. Retomada, re-execução e falhas

| Situação | O que fazer |
|---|---|
| Cliente parou no meio do assessment | Salve `data/assessments/{slug}-partial.yaml`, retome da última seção fechada |
| Um agente não conseguiu classificar | Marque confiança < 0.5, siga, e no Blueprint escreva "indicativo, não conclusivo" |
| Cliente quer refazer meses depois | Novo arquivo com sufixo de data. **Não sobrescreva** o antigo: a comparação entre os dois é o produto |
| Cliente tem Kolbe A Index ou CliftonStrengths oficial | O resultado formal sobrescreve a estimativa do squad |
| Respostas contraditórias no questionário | Não interrompa. Anote e trate como tensão na Etapa 2 |

---

## 7. Checklist de instalação (rode uma vez)

- [ ] `squads/zona-genialidade/` existe com `agents/`, `tasks/`, `workflows/`, `data/`, `config.yaml`
- [ ] 8 arquivos em `agents/` (7 minds + chief)
- [ ] 5 arquivos em `tasks/` (start, run-assessment, analyze-genius-profile, recommend-squad, generate-blueprint)
- [ ] `data/assessments/` existe e é gravável
- [ ] Comandos publicados em `.claude/commands/ZonaGenialidade/` e `.claude/commands/zona-genialidade/`
- [ ] Teste de fumaça: rode `/ZonaGenialidade:tasks:start`, responda a Seção 1 e confirme que o YAML apareceu em `data/assessments/`

Se o teste de fumaça não gerar arquivo, o resto do pipeline não roda. Conserte antes de atender alguém.

---

## 8. Onde ficam os dados de quem você atende

`data/assessments/` nasce vazio neste pacote. Cada atendimento grava ali o YAML do seu próprio
assessment. **Uma pasta por pessoa, sempre em kebab-case** (`data/maria-souza/`). Nenhum perfil de
outra pessoa vem embutido: não existe modelo pronto para copiar, e não deve existir.

---

_Runbook do squad zona-genialidade. Se este arquivo divergir de outro do squad, este manda na ordem de execução e o `tasks/*.md` manda no conteúdo de cada etapa._
